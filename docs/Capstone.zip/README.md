Udacity Machine Learning Capstone Project
---

This is the capstone project I completed as part of Udacity's Machine Learing Nanodegree's requirement.
I've built a model that can predict whether a bank customer is satisfied with the bank and banking expereince or not.

The data for this project has been acquired from:
- https://www.kaggle.com/c/santander-customer-satisfaction/data

The libraries needed for this project:
- scikit-learn
- pandas
- numpy
- matplotlib
- seaborn
- xgboost